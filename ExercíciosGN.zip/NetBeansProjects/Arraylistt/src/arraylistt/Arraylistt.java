/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arraylistt;
import java.util.Scanner;
import java.util.ArrayList;
public class Arraylistt {


    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
        String nome;
        ArrayList<String> nomes = new ArrayList<>();
        
        
     
        for(int i =0;i<5;i++){
        System.out.println("digite o nome:");
        nome=scan.nextLine();
         nomes.add(nome);  
        }
        for(int j=0;j<nomes.size();j++){
            System.out.println(nomes.get(j));
       
        }
        System.out.println("Digite 1 para remover o primeiro nome:");
        int n=scan.nextInt();
        if( n == 1){
        nomes.remove(0);
        for(int t=0;t<nomes.size();t++){
            System.out.println(nomes.get(t));
       
            } 
        }else{
            System.out.println("nao foi removido");
         
       }
        
   
        
    }
    
}
