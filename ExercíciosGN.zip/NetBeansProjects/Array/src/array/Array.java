
package array;
//ver se um certo caracter da primeira aparece quantas vezes na segunda
import java.util.Scanner;

public class Array {

    public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);  
    String s1;
     String s2;
        System.out.println("Digite a primeira string:");
        s1=scanner.next();
        System.out.println("Digite a segunda string:");
        s2=scanner.next();
        
        String contados= "";
       
        for(int i=0;i<s1.length();i++){
        char atual = s1.charAt(i);
        
        if(contados.indexOf(atual)== -1){ //“Procure o caractere ataual dentro da string contadoss. e o -1 quer dizer no caso de nao exister e nao propriamente a posicao antes do 0”
        int contador =0;
        for(int j=0;j<s2.length();j++){
            if(s2.charAt(j) == atual){      
           contador++;
           }
           
        }
        System.out.println(" o caracter " + atual + " aparece " + contador + "vezes na segunda string");
        contados+=atual; //adiciona e guarda caracteres
        }       
        }    
    
               
        
        
    }
    
}
