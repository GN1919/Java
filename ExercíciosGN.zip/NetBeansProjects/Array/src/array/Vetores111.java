/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package array;

import java.util.Scanner;
public class Vetores111 {
    
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int [] n   = new int [5];
       
        
        for(int i =0;i <n.length; i++){
        System.out.println("Digite o numero:");
        n[i]=scan.nextInt();
    }
        System.out.println("\n");
    for(int i=n.length; i >= 0; i-- ){
         System.out.println(i);
    }    
        
        
        
        
    }
    
    
    
}
