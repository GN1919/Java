
package array;
import java.util.Scanner;
import java.util.Arrays;


public class Capicua {
   public static void main(String[] args) {
       Scanner keyboard = new Scanner(System.in);
       String s;
       System.out.print("digite a String:");
       s=keyboard.next();
       int f = s.length()-1;
       for(int i = 0; i < s.length() ; i++){
           if(s.charAt(i) != s.charAt(f)) break;
           f--;
       } 
    if(f == -1) {
        System.out.println("IS Capicua");
    }else System.out.println("NAO Capicua");
   }  
    
}
