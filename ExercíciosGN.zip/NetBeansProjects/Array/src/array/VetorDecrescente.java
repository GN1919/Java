
package array;
//ordena de forma decrescente
import java.util.Scanner;
public class VetorDecrescente {
      public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int [] n   = new int [5];
       
        
        for(int i =0;i <n.length; i++){
        System.out.println("Digite o numero:");
        n[i]=scan.nextInt();
        }
         
        System.out.println("\n");
        int aux;
        for(int i=0; i <n.length-1;i++ ){
            for(int j =0; j<n.length-1-i;j++){ // n.length -1 - i evita q seja acessado um numero fora do vetor
         if((n[j] <  n[j+1])){
             aux = n[j];// guarda o valor de n[i] em aux pra nao se perder o valor
             n[j]=n[j+1];//agora para a posicao n[i] passa a receber o valor da posicao seguinte q e n[i+1]
            n[j+1] = aux;//e depois na posicao n[i+1] q ja foi desocupada pois o valor foi para a posicao n[i] passa a receber o valor de aux q e o foi copiao(n[i])
               
         } 
         
            }
                
        }    
                
        System.out.println("Vetor ordenado de forma decrescente:");
        for(int i = 0; i < n.length; i++) {
            System.out.print(n[i] + " ");
       
        
        }

      }
    
    
    
}
