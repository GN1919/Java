
package matrizexercicio;

public class Matrizexercicio {

  
    public static void main(String[] args) {
     int Matriz [] [] = new int [3] [2];
     Matriz [0] [0] = 2;
      Matriz [0] [1] = 3;
       Matriz [1] [0] = 4;
        Matriz [1] [1] = 5;
         Matriz [2] [0] = 6;
         Matriz [2] [1] = 2;
        int linha;
        int coluna;

    for (linha =0; linha < Matriz.length;linha++){
    for ( coluna =0; coluna < Matriz[linha].length;coluna++){
        System.out.print(Matriz[linha]  [coluna]+ "  ");
    }
     System.out.println("");
    }
    
}
}