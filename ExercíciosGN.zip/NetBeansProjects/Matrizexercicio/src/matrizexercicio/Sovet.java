
package matrizexercicio;


public class Sovet {
    public static void main(String[] args){
     
        int  vetor1 [5]= {6,7,8,9,9};
        int  vetor2 [5] = {1,2,3,4,5};
        int resultado []=new int [10];
        
             System.out.println(resultado);
        
        
          
        
    }
    
    
  
    
}
