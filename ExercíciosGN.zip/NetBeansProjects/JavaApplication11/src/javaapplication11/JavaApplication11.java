/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication11;

import java.util.Scanner;
import java.util.Array;


public class JavaApplication11 {

    public static void main(String[] args) {
       
  Scanner scan=new Scanner(System.in);
        int [] numer = new int [8];
        
        System.out.println("Digite o numero");
        numer = scan.nextInt();
        System.out.println("IMPRIMA OS VALOR"+numer);

    }
    
}
