/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio4;

import java.util.Scanner;
public class RecebeVarios {
     public static void main(String[] args){
    Scanner scan = new Scanner(System.in);
    int n;
    int contador=0;
    int soma = 0;
    
     do{
         System.out.println("Digite o numero: ");
         n=scan.nextInt();
        
         if(n >= 0 && n % 2 == 0){
             soma = soma + n;
               contador++;
         }
           
     }while(n >=0) ;
       
       
     System.out.println(" a media entre numeros multiplos de 2 e : " + soma/contador);   
       scan.close();
   
   }
}
