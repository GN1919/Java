
package exercicio4;
import java.util.Scanner;

public class Intervalodo12 {
       public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
           int n1;
           int n2;
        
        System.out.println("digite o primeiro numero");
           n1=scanner.nextInt();
           System.out.println("digite um numero maior q o anterior");
           n2=scanner.nextInt();
           System.out.print("Os numeros neste intervalo sao: " + "\n");
           
           for(int i = n1+1; i < n2;i++){
               
               System.out.println(i);
           }
               
        
        
        
        
        
        
}
}