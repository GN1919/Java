
package exercicio4;
import java.util.Scanner;
public class Exercicio4 {

   
    public static void main(String[] args) {
       
        //
        Scanner teclado = new Scanner(System.in);
        int [] numero= new int[5];
      
        for(int i = 0;i < numero.length;i ++){
       System.out.println("digite o numero:");
        numero[i]=teclado.nextInt();   
    }
        for(int i = 0; i< (int) numero.length; i++) {
            if(numero[i] > max) max = numero[i];
            if(numero[i] < min) min = numero[i];
        }
        
      
    
teclado.close();

        
        
        
    }
    
}
