
package exercicio4;

import java.util.Scanner;
public class NegativeNumber {
   public static void main(String[] args){
    Scanner scan = new Scanner(System.in);
    int n;
    int contador=0;
    
     do{
         System.out.println("Digite o numero: ");
         n=scan.nextInt();
         if(n>0 && n<8){
             contador++;
         }
  
         
     }while(n >0) ;
       
       System.out.println("Os numeros menores q oito sao : " + contador);   
     scan.close();
   
   }
}