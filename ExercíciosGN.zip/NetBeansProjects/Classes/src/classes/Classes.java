
package classes;

import java.util.Scanner;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.IOException;
public class Classes {
    public static void main(String[] args)throws IOException {
        //caminho pra onde as escrituras vao, // Goldwyn.txt e o meu arquivo
        String caminho = "C:\\Users\\PC\\Desktop\\Goldwyn.txt";
       //para escrever dados no arquivo de texto,e o true serve para nao apagar o conteydo existente e sim adicionar
        FileWriter escreve = new FileWriter(caminho,true);
      //para melhor desempenho
        BufferedWriter escrevecomdesempenho = new BufferedWriter(escreve);
        
    
        Scanner scan = new Scanner(System.in);
        
      System.out.println("digite o nome:");
         String nome=scan.nextLine();
         System.out.println("digite a idade:");
         int idade=scan.nextInt();
        
         ClassePessoa p = new ClassePessoa(nome,idade);
           escrevecomdesempenho.write(nome + "\r\n");
          
           escrevecomdesempenho.close();
           
          try{
           
           BufferedReader leitor = new BufferedReader (new FileReader(caminho));
           String linha;//guarda temporariamente o valor lido para retornar
          
           while((linha=leitor.readLine())!=null){
               // esta comparacao deve se colocar em aspas pra evitar erros entre tipos primitvos
               System.out.println(linha);
           }
           leitor.close();
          }catch (IOException e){
                   System.out.println("erro ao ler arquivo ");
                   }
           
           
           
         p.Exibir();
               
            
       scan.close();
        
    }
    
}
