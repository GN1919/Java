
package classes;

public class ClassePessoa {
  String nome;
  int idade;
  
  public ClassePessoa(String nome, int idade){
      this.nome=nome;
      this.idade=idade;
      
  }
  public void Exibir(){
   System.out.println(nome+idade);
      
      
  }
}     