
package projeto;
//construtor
public Animal(String nome,String especie,String raca,LocalDate datanascimento,Proprietario proprietario){
      this.especie=especie.toUpperCase();
      this.id= "cli" + String.format("%03d",contador ++) + "ao";//do tipo inteiro  e deve ter tres digitos com 0 a esquerda
      this.idade=calidade();//nao passamos por parametro q nao e necessario uma vez q gerado auto atraves da datanascimento
      this.visita=new ArrayList<>();
      this.raca=raca.toUpperCase();
      this.nome=nome.toUpperCase(); 
      try{
          Validacao.validarDataNascimento(datanascimento);
          this.datanascimento=datanascimento;
}catch(IllegalArgumentException e) {
          System.out.println("recebendo Data padrao");
          this.datanascimento = LocalDate.of(2020,1,1);
      }
      
      this.proprietario=proprietario;      


//no metodo registrar animal
    system.out.println("Digite a data de nascimento do Animal no formato AAA-MM-DD:");
        String datanascimento=teclado.nextLine();
        LocalDate data =LocalDate.parse(datanascimento.trim());
           System.out.println("A data foi processada com sucesso. " + data);
       
//validar a data

caso queereres ver a classe q valida :data public static boolean validardatavisita(LocalDate dataVisita){
      return dataVisita !=null && !dataVisita.isAfter(LocalDate.now());
  } 
    











  }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
