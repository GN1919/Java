
package projeto;
public abstract class  Pessoa {
    int id;
    String Nome;
}
