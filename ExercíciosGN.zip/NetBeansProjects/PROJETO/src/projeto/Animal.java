
package projeto;

public class Animal extends Pessoa {
    
}
