package projeto;


public class PROJETO {
    public static void main(String[] args) {
        Animal a=new Animal();
        a.id = 2;
        System.out.println(a.id);
    }
    
}
