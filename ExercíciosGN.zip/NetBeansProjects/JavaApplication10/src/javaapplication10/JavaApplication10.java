
package javaapplication10;

import java.util.Scanner;


public class JavaApplication10 {

    public static void main(String[] args) {
          Scanner scan=new Scanner(System.in);
        int[] numer=new int[8];
        System.out.println("Digite o numero");
        numer=scan.nextint();
        System.out.println("IMPRIMA OS VALOR"+numer);
    }
    
}
