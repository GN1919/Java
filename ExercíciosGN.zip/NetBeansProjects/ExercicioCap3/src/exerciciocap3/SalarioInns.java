
package exerciciocap3;
import java.util.Scanner;

public class SalarioInns {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Digite o nome: ");
        String nome = teclado.nextLine();

        System.out.print("Salario Base: ");
        float salario = teclado.nextFloat();

        System.out.print("Desconto do INSS: ");
        float desconto = teclado.nextFloat();

        desconto = desconto /100;

        float liquido = salario - (salario * desconto);

        System.out.printf("%s seu salario liquido é de : %.2f KZ", nome, liquido);
        teclado.close();
    } 
}
