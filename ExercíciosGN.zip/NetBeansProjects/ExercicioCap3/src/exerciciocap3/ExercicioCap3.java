
package exerciciocap3;
import java.util.Scanner;
public class ExercicioCap3 {

   
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
        float a, b, c;

        System.out.print("Digite o valor1: ");
        a = teclado.nextFloat();

        System.out.print("Digite o  valor2: ");
        b = teclado.nextFloat();

        System.out.print("Digite o  valor3: ");
        c = teclado.nextFloat();

        float soma = a+b+c;
        float subtracao = a-b-c;
        float multiplicacao = a*b*c;
        float divisao = 0;

        

        System.out.println("RESULTADOS");
        System.out.printf("Soma = %.2f%n", soma);
        System.out.printf("Diferença = %.2f%n",subtracao);
        System.out.printf("Multiplicação = %.2f%n", multiplicacao);
        
        if(b == 0 || c == 0){
            System.out.print("Impossivel fazer a divisão por zero.");
        }else{
             divisao = a / b / c;
             System.out.printf("Divisão = %.2f", divisao);
        }
        
        
        
        
    }
    
}
