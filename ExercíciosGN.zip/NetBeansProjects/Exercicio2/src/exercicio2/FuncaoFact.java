
package exercicio2;

import java.util.Scanner;
public class FuncaoFact {
   public static int Media(int n1, int n2, int n3){
       
           int media = (n1 + n2 + n3) / (3);
   
       return  media;
   } 
      
    
    
    
        public static void main(String[] args){
        Scanner teclado = new Scanner(System.in);
         int s1;
         int s2;
         int s3;
         System.out.println("Digite a prova1:");
          s1=teclado.nextInt();
         
          System.out.println("Digite a prova2:");
          s2=teclado.nextInt();
         
          System.out.println("Digite a prova3:");
          s3=teclado.nextInt();
            System.out.print("");
            System.out.println("a media e " + Media(s1,s2,s3));//passagem de paranmetro
         
       
         
         
         
}
}