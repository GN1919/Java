
package exercicio2;


public class Recursiva {
    public static int fatorial(int n) {
    if (n == 0) {         // Caso base: fatorial de 0 é 1
        return 1;
    } else {              // Caso recursivo: calcula n * fatorial(n-1)
        return n * fatorial(n - 1); /* basicamente e fazer com q a funcao chegue no caso base q  e
                                     fatorial de 0 q e 1 e depois pegar a cada valor a seguir
                                      fazer com q multiplique com a fatorial anterior para se conseguir a fatorial do numero corrente
                                */
        
        
        
        
    }
}
    public static void main(String[] args){
        int n = 4;
        System.out.println(fatorial(n));
        
     
    }  
        
}
