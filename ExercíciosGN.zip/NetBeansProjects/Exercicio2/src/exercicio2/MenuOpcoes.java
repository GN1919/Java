

package exercicio2;
import java.util.Scanner;
   public class MenuOpcoes {
  public static void menu(){
   Scanner teclado = new Scanner(System.in);
      int n;   
 do{
     
         System.out.println("\n====welcome to site BuyYourFirstHouse===");
         System.out.println("1---buy a house in london.");
         System.out.println("2---buy a house in Angola ");
         System.out.println("3---click 3 to go out.");
        
         System.out.println("Digite uma opcao Andre:");
         n=teclado.nextInt();
          switch(n){
              case 1:
                  System.out.println("==1house to pay 20k dolars==");
                   System.out.println("==2house to pay 68k dolars==");
                    System.out.println("Select 1 or 2 for your purchase:");
                    int a = teclado.nextInt();
                    System.out.println("purchase is done!");
                  
                  break;
              case 2:
                  System.out.println("==1house to pay 69k dolars==");
                    System.out.println("==2house to pay 100k dolars==");
                  
                  System.out.println("Select 1 or 2 for your purchase");
                     int  b = teclado.nextInt();
                      System.out.println("purchase is done!");
                  break;
              case 3:
                  System.out.println("encerrado!");
                  
                  break;
              default:
                  System.out.println("opcao invalido");
          }
          
          }while(n!=3);
       teclado.close();
   }      
       
    
    
   public static void main(String[] args){
        menu();
       
          
    
    
    }
    
}
