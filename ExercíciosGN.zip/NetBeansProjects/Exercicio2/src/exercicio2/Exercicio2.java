
package exercicio2;
import java.util.Scanner;

public class Exercicio2 {

    
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
        int [] numero= new int[5];
       int max = -100000; // para q qualquer valor q seja ditado seja maior e consequentemente maior q o  nosso maximo
       int min= 100000; // o inverso 
        
        for(int i = 0;i <numero.length;i ++){
       System.out.println("digite o numero:");
        numero[i]=teclado.nextInt();   
    }
        for(int i = 0; i< (int) numero.length; i++) {
            if(numero[i] > max) max = numero[i];
            if(numero[i] < min) min = numero[i];
        }
        
        System.out.printf("Max:%d\nMin:%d", max, min);
    }
 
    
}
