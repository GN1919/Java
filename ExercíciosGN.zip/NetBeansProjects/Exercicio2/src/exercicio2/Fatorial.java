
package exercicio2;


public class Fatorial {
  public static void main(String[] args){
      int n = 2;
      int fact = 1;
      for(int i = 1;i <= n; i++){
          fact *= i;
      }   
          
      
        System.out.print("fatorial " + fact );
      
      
      
      
  }
     
    
    
}
