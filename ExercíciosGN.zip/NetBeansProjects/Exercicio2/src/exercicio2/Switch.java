
package exercicio2;
import java.util.Scanner;

public class Switch {
     public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
         int n;
         System.out.println("Digite algum numero de 0 a 2:");
         n=teclado.nextInt();
         switch(n){
             case 0:
                 System.out.println("digitou 0!");
                 break;
             case 1:
                 System.out.println("digitou 1!");
                 break;
             case 2:
                 System.out.println("digitou 2!");
                 break;
                
             default:
                 System.out.println("inavalido zeca");
         }
    
    
    
    
}
}