
package exerccap2;
import java.util.Scanner;
//emprestimo so se a prestacaom for maior 1 20 porcento do salario
public class Exerccap21 {
  public static void main(String[] args) {
          Scanner scan = new Scanner(System.in);
          
          System.out.println("digite o seu salario: ");
      
          double salario = scan.nextDouble();
  
          System.out.println("digite a prestacao de emprestimo: ");
          
          double prestacao= scan.nextDouble();
           
          
          if(prestacao  > (salario * 20) / 100  ){
              System.out.print("emprestimo nao concedido: ");
  
           }else{
  
              System.out.print("emprestimo concedido: ");
  
           }
           scan.close();
    
  }    
    
    
}
