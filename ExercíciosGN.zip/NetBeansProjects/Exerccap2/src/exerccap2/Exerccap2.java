
package exerccap2;
import java.util.Scanner;
public class Exerccap2 {


    public static void main(String[] args) {
     Scanner scan = new Scanner(System.in);
          //calculo da media
          System.out.println("digite a nota da prova1: ");
      
          double prova1 = scan.nextDouble();
  
          System.out.println("digite a nota da  prova2: ");
          
          double prova2= scan.nextDouble();

          
          System.out.println("digite a nota da prova3: ");
          
          double prova3= scan.nextDouble();

           double media = (prova1*2 + prova2*3 + prova3*5) / (10);
          
        
              System.out.printf("A sua media e: %.3f", media);
  
  
           scan.close();
        
        
        
        
        
        
        
    }
    
}
