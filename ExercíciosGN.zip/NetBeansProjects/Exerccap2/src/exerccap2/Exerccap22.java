
package exerccap2;

import java.util.Scanner;
public class Exerccap22 {
      public static void main(String[] args) {
          Scanner scan = new Scanner(System.in);
          
          System.out.println("digite o seu salario: ");
      
          double salario = scan.nextDouble();
  
          if(salario <= 0 ){
              System.out.print("salario invalido ");
  
           }else if(salario > 1000){
            
  
              System.out.printf("pagamento de 10 porcento: %.1f ", (salario * 10) / 100);
  
           }else{
            System.out.printf("pagamento de 5 porcento: %.1f ", (salario * 5) / 100);
           }

          
      }
    
    
    
    
}
