/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exerccap2;

import java.util.Scanner;
public class SusbtiString {
       public static void main(String[] args) {
       Scanner keyboard = new Scanner(System.in);
       String s;
       System.out.print("digite a String em maiuscula:");
       s=keyboard.next();
       String result = "";
       for(int i = 0; i < s.length() ; i++){
            char atual = s.charAt(i);
           if(atual == 'A'){
               result = result + 'T';
               System.out.println("Substuindo A por T!");
           }else if(atual == 'E'){
               result = result + 'H';
               System.out.println("Substituindo E por H");
           }else if(atual=='I'){
                result = result + 'A'; 
                 System.out.println("Substituindo I por A");
           }else{
               result = result + atual;
                System.out.println("Carcater mantido E " + atual);
           }
           System.out.println(result); // A CADA MUDANCA DE CARCATERES O PROGRAMA MOSTRA OS PASSOS
       }
       }
       }