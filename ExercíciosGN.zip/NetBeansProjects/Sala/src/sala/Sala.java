package sala;
import java.util.Scanner;
/**
 *
 * @author Garcianoh
 */
public class Sala {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String nome;
        System.out.print("Digite um nome:");
        nome=scanner.nextLine();
        System.out.println("Nome:"+nome);
        
        scanner.close();
    }
    
}
