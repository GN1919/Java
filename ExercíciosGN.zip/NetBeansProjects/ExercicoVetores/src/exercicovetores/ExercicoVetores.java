


package exercicovetores;
import java.util.Scanner;

public class ExercicoVetores {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
      int [] vetor=new int[5];
      for(int i=0;i<vetor.length;i++){
          System.out.print("Digite um numero:");
          vetor[i]=scanner.nextInt();
      }
      for(int j=vetor.length-1 ; j>=0 ; j--){
          System.out.print(vetor[j]+" ");
      }
    
    
    }
    
}
