
package pungo.andongo;
import java.util.ArrayList;

public class Proprietario extends Superclasse {
  private String contacto;
  private ArrayList<Animal> animais;  

private static int contador = 1; 
public Proprietario(String nome,String contacto){ //nao inicializamos o array pq os animais sao associados dps um por um
  this.nome=nome.toUpperCase();
  this.id= "pro" + String.format("%03d",contador ++) + "ao";//GERA ID AUTO
 this.contacto=contacto;
  this.animais=new ArrayList <> ();
}
 
public Proprietario(){
     this.nome="indefinido";
     this.id="indefinido";
     this.animais=new ArrayList <> ();
     this.contacto="indefinido";
 }
public String getnome(){
    return this.nome;
}
public String getid(){
    return this.id;
}
public String getcontacto(){
    return this.contacto;
}
public ArrayList<Animal> animais(){
    return this.animais;
}
public void setnome(String nome){
     this.nome=nome;
}
public void setid(String id){
     this.id=id;
}
public void setcontacto(String contacto){
    this.contacto=contacto;
}


public void AdicionarAnimal(Animal animal){
    this.animais.add(animal);
}
public ArrayList<Animal> getAdicionarAnimais() {
    return animais;
}

@Override
  public String toString(){ 
      return "Proprietario[id= " + id + ", Nome= " + nome + ", contacto= " + contacto + " , Animais= " + animais.size() +  "]" ;
  }    
    
  
public void ListarAnimaisProp(){
    if(animais.isEmpty()){
        System.out.println("Este proprietario nao possui animais");
    }else{
        System.out.println("Animais do proprietario " + nome + ":");
        for(int i =0;i<animais.size();i++){
            System.out.println(animais.get(i));
        }
    }
    
 

    
}

   
}