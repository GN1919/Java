
package pungo.andongo;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.FileReader;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;
public class ArquivoTxt {
     private static final String NomeArquivo = "C:\\Users\\PC\\Desktop\\VeterinarioPungoAndongo.txt";//caminho do arquivo
    public static void SalvarAnimais(ArrayList<Animal> animais){ //o nome do arquivo ja e constante 
      if (animais == null || animais.isEmpty()) {
        System.out.println("Nenhum animal foi registrado.");
        return; // Sai do método
    }

       
         try {
            // Cria um escritor de arquivos com buffer (eficiente) e abre o arquivo com o nome passado
            FileWriter escrever = new FileWriter(NomeArquivo,true);
            BufferedWriter escrever2 = new BufferedWriter(escrever);
         
            // Percorre o ArrayList de animais usando o índice
            for (int i = 0; i < animais.size(); i++) {
                Animal a = animais.get(i); // Pega o animal da posição i
                escrever2.write(a.toString()); // Escreve os dados do animal usando o método toString()
                escrever2.newLine(); // Adiciona uma quebra de linha
            }
              escrever2.close();
             // Mensagem de sucesso
            System.out.println("Animais salvos com sucesso no arquivo " + NomeArquivo);
        } catch (IOException e) {
            // Caso ocorra erro ao escrever no arquivo, exibe a mensagem de erro
            System.out.println("Erro ao salvar animais: " + e.getMessage());
        }
    }
    //metodo salvar prop
       public static void SalvarProprietarios(ArrayList<Proprietario> proprietarios){ 
        if (proprietarios == null || proprietarios.isEmpty()) {
        System.out.println("Nenhum proprietario foi registrado.");
        return; // Sai do método
    }

       
         try {
            // Cria um escritor de arquivos com buffer (eficiente) e abre o arquivo com o nome passado
            FileWriter escrever = new FileWriter(NomeArquivo,true);
            BufferedWriter escrever2 = new BufferedWriter(escrever);
         
            // Percorre o ArrayList de animais usando o índice
            for (int i = 0; i < proprietarios.size(); i++) {
                Proprietario p = proprietarios.get(i); // Pega o animal da posição i
                escrever2.write(p.toString()); // Escreve os dados do animal usando o método toString()
                escrever2.newLine(); // Adiciona uma quebra de linha
            }
              escrever2.close();
             // Mensagem de sucesso
            System.out.println("Proprietarios salvos com sucesso no arquivo " + NomeArquivo);
        } catch (IOException e) {
            // Caso ocorra erro ao escrever no arquivo, exibe a mensagem de erro
            System.out.println("Erro ao salvar animais: " + e.getMessage());
        }
         //metodo salvar visita
       }   
         public static void SalvarVisitas(ArrayList<Visitas> visitas){ 
        if (visitas== null || visitas.isEmpty()) {
        System.out.println("Nenhuma vista feita.");
        return; // Sai do método
    }

       
         try {
            // Cria um escritor de arquivos com buffer (eficiente) e abre o arquivo com o nome passado
            FileWriter escrever = new FileWriter(NomeArquivo,true);
            BufferedWriter escrever2 = new BufferedWriter(escrever);
         
            // Percorre o ArrayList de animais usando o índice
            for (int i = 0; i < visitas.size(); i++) {
                Visitas v =visitas.get(i); // Pega o animal da posição i
                escrever2.write(v.toString()); // Escreve os dados do animal usando o método toString()
                escrever2.newLine(); // Adiciona uma quebra de linha
            }
              escrever2.close();
             // Mensagem de sucesso
            System.out.println("Visitas salvas com sucesso no arquivo " + NomeArquivo);
        } catch (IOException e) {
            // Caso ocorra erro ao escrever no arquivo, exibe a mensagem de erro
            System.out.println("Erro ao salvar visita: " + e.getMessage());
        }
         }
         
         
         public static void LerArquivo() {
        File arquivo = new File(NomeArquivo);

    // Verifica se o arquivo existe
    if (!arquivo.exists()) {
        System.out.println("Arquivo ainda não foi criado ou esta vazio.");
        return;
    }

    try {
        FileReader leitor = new FileReader(arquivo);
        BufferedReader buffer = new BufferedReader(leitor);

        String linha;
        System.out.println("==== Conteudo do Arquivo ====");
        while ((linha = buffer.readLine()) != null) {
            System.out.println(linha);
        }

        buffer.close();
    } catch (IOException e) {
        System.out.println("Erro ao ler o arquivo: " + e.getMessage());
    }
}

         
         
         
         
         
         
         
         
         
         
    }

    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
    
    
    
    
    
    
    
    
  
    
    

