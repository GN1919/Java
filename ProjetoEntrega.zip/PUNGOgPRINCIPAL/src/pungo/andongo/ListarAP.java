
package pungo.andongo;
import java.util.ArrayList;
public class ListarAP {
    
    public static void ListarAP(ArrayList<Proprietario> proprietarios){
       if(proprietarios.isEmpty()){
           System.out.println("Nenhum proprietario registrado");
           return;
       } 
        
    for(int i=0;i<proprietarios.size();i++){
        Proprietario p=proprietarios.get(i);//obtem um proprietario atual numa determinada psoicao na posicao
        System.out.println("Proprietario " + p.getnome());
       
        ArrayList<Animal> animais = p.animais();//a obter a lista de animais de um...
        if(animais.size()==0){
            System.out.println("Nenhum animal registrado!");
        }else{
            for(int j=0;j<animais.size();j++){
                System.out.println("Animal: " + animais.get(j).getnome());
            }
        }
        
    }    
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
    
}
