
package pungo.andongo;

import java.time.LocalDate;

import java.util.ArrayList;
public class Animal extends Superclasse {
   private  Proprietario proprietario; 
  private String especie;
  private int idade;
  private String raca;
  private LocalDate datanascimento;
  private ArrayList<Visitas> visita = new ArrayList <>();
  
  public int calidade(){
      int anoatual= 2025;
      return anoatual-datanascimento.getYear(); //getyear da o ano do metodo LocalDate
    
  }
 
  
 
  private static int contador = 1;
  
  public Animal(String nome,String especie,String raca,LocalDate datanascimento,Proprietario proprietario){
      this.especie=especie.toUpperCase();
      this.id= "cli" + String.format("%03d",contador ++) + "ao";//do tipo inteiro  e deve ter tres digitos com 0 a esquerda
      
      this.visita=new ArrayList<>();
      this.raca=raca.toUpperCase();
      this.nome=nome.toUpperCase(); 
      
       this.datanascimento=datanascimento;
         
        
      this.idade=calidade();//nao passamos por parametro q nao e necessario uma vez q gerado auto atraves da datanascimento
      this.proprietario=proprietario;      
  }
  
  //sobrecarga
  public Animal(){
      this.especie="indefinado";
      this.id="indefinido";
      this.idade=-1;
      this.raca="indefinido";
      this.nome="indefinido"; 
      this.proprietario=null;
  }
  
  public void adicionarVisita(Visitas visita) {
    this.visita.add(visita);
}

public int getQuantidadeVisitas() {
    return visita.size();
}
  public ArrayList<Visitas> getvisita(){
      return this.visita;
  }
  public String getespecie(){
      return this.especie;
  }
  
  public String getid(){
      return this.id;
  }
  public int getidade(){
      return this.idade;
  }
  public LocalDate getdatanascimento(){
      return this.datanascimento;
  }
  public String getraca(){
      return this.raca;
  }
  public String getnome(){
      return this.nome;
  }
  public Proprietario getProprietario(){
      return this.proprietario;
  }
  public void setespecie(String especie){
      this.especie=especie;
  }
  public void setid(String id){
      this.id=id;
  }
  public void setidade(int idade){
       this.idade=idade;
  }
  
  public void setraca(String raca){
      this.raca=raca;
  }
  public void setnome(String nome){
       this.nome=nome;
  }
  
  public void setProprietario(Proprietario proprietario){
      this.proprietario=proprietario;
  }
  
  public void exibirvisitas(){
      if(visita.isEmpty()){
          System.out.println("Animal ainda nao tem visitas");
        
      }else{
          System.out.println("Numeeros de visitas: " + visita.size());
          for(int i=0;i<visita.size();i++){
          System.out.println( visita.get(i));//o metodo tostring e chamado auttomaticamente aqui
      }
      
  }
  }
  
 @Override
 public String toString(){
      String infoAnimal = "Animal[" + "id= " + id  +  ", Nome= " + nome +   " ,idade= " + idade +  ", Especie= " + especie +   ", raca= " + raca  + ", Proprietario= " + proprietario.getnome() + ", NumerodeVisitas= " + visita.size() +  "]" ;
             // Adiciona as visitas se houverem
    if (visita != null && !visita.isEmpty()) {
        infoAnimal += "\nTipos de Visita: ";
        for (int i = 0; i < visita.size(); i++) {
            Visitas v = visita.get(i);
            infoAnimal += v.getTipoVisita();
            if (i < visita.size() - 1) {
                infoAnimal += ", ";
            }
        }
    } else {
        infoAnimal += "\nNenhuma visita registrada.";
    }

    return infoAnimal; 
             
             
             
            
              
             
             
  }    
      
      
  
 
  } 
    
    
      
    
    
