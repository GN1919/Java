
package pungo.andongo;

import java.util.ArrayList;
//pra registar animal deve se ter um proprie e bsucar esse msm
public class BuscarProprietario {
   //PRECISAMOS DE PROCURAR NA LISTA DE PROPRIETARIOS,PQ O PROPRIETARIO JA DEVE ESTAR REGISTRADO
       //metodo da classe e com tipo de retorno Proprie...
    public static Proprietario BuscarProprietario(String nome, ArrayList<Proprietario> proprietarios){
             for(int i=0;i<proprietarios.size();i++){
             Proprietario atual=proprietarios.get(i);
                if(atual.getnome().trim().equalsIgnoreCase(nome.trim())){    //o nome registrado com o nome digitadocorrentemente pelo usuario
                     return atual;
         }
    } 
     return null;   
    
} 
    
    
    
    
    
    
}
