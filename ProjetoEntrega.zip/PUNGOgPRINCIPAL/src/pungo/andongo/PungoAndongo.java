
package pungo.andongo;
import java.util.Scanner;
import java.time.LocalDate;
import java.util.ArrayList;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;

public class PungoAndongo{
//sao estaticos entao declara se fora e antes de tds metodos
         public static ArrayList<Proprietario> proprietarios = new ArrayList<>();//pq public deve permitir acessar esse na classe arquivo txt
          public static ArrayList<Animal> animais = new ArrayList<>();//|||
          public static ArrayList<Visitas> visitas = new ArrayList<>();
    public static void main(String[] args) {
       
        
   
    PungoAndongo novo = new PungoAndongo();
    Scanner teclado = new Scanner(System.in);
    
int opcao;
   
      do{
             System.out.println("====== SEJA BEM-VINDO A PUNGOANDONGO ======");
             System.out.println("1. ==Registrar proprietario==");
             System.out.println("2. ==Registrar animal==");
             System.out.println("3. ==Registrar visita==");
             System.out.println("4. ==Listar animais com proprietarios==");
             System.out.println("5. ==Listar animais registrados==");
             System.out.println("6. ==pesquisar animais de um proprietario==");
             System.out.println("7. ==Listar visitas de um animal==");
             System.out.println("8. ==Listar Historico de Visitas por animais==");
             System.out.println("9. =Salvar no arquivo de texto==");
              System.out.println("10. =Ler dados do arquivo de texto==");
             System.out.println("11. ==Sair==");
             
         System.out.print("Digite a opcao: "); 
    opcao = teclado.nextInt();
    teclado.nextLine();

    switch(opcao) {
        case 1:
            novo.registrarProp(teclado); //como os metodos sao nao estaticos entao tivemos q isnatnaciar um objetoda class..
            break;
        case 2:
            novo.registrarAnimal(teclado); 
            break;
        case 3:
            novo.registrarVisita(teclado);
            break;
        case 4:
            novo.ListarAnimaisProp(proprietarios);
            break;
        case 5:
            novo.ListarTodosAnimais(animais);
            break;
        case 6:
            novo.BuscarAnimaisPorProprietario(teclado);
            break;
        case 7:
             novo.ContarVisitasPorTipo(teclado);
            break;
        case 8:
           novo.listarHistoricoVisitas(teclado);
            break;
        case 9:
            ArquivoTxt.SalvarAnimais(animais);//foi declarado com static entao nao se precisa instanciar
            ArquivoTxt.SalvarProprietarios(proprietarios);
            ArquivoTxt.SalvarVisitas(visitas);
        case 10:
            ArquivoTxt.LerArquivo();
        case 11:
            System.out.println("Saindo...");
            break;
        default:
            System.out.println("Opcao invalida.");
          }
      }while(opcao != 9);
}

 //registrar Animal
       public  void registrarAnimal(Scanner teclado){
        System.out.println("Digite o nome do Animal:");
        String nome=teclado.nextLine();
        System.out.println("Digite a Especie do Animal:");
        String especie=teclado.nextLine();
        System.out.println("Digite a raca do Animal:");
        String raca=teclado.nextLine();
        //propr com validacao
        System.out.println("Pesquise o nome do proprietario do Animal:");
        String proprietario =teclado.nextLine();
        Proprietario dono = BuscarProprietario.BuscarProprietario(proprietario,proprietarios);//dono acessa o metodo buscar proprietario
        if(dono==null){
            System.out.println("Proprietario nao encontrado,Registre-se primeiro!");
          return;
        }else{
            System.out.println("Nome encontrado: " + "[" + dono.getnome() + "].");
        }
        //data com validacao
       LocalDate data=null;
       while(true){
        System.out.println("Digite a data de nascimento do Animal que deve estar entre 2020 a 2025 no formato AAA-MM-DD:");
        String datanascimento=teclado.nextLine();
        
        try{
               data =LocalDate.parse(datanascimento.trim());
               Validacao.validarDataNaoFutura(data);
               Validacao.validarDataNascimento(data);
               break;
        }catch(IllegalArgumentException | DateTimeParseException e){
               System.out.println("Erro data: " + e.getMessage());
             
    }     
  
}      //criando animal
        Animal novo = new Animal(nome,especie,raca,data,dono);
        dono.AdicionarAnimal(novo);
        animais.add(novo);
           System.out.println("Animal adicionado com sucesso!");
           System.out.println(novo);
        
           
       }       
        //registrar proprietario
       public void registrarProp(Scanner teclado){
           System.out.println("Digite o nome do proprietario:");
           String nome=teclado.nextLine();
           System.out.println("Digite o contacto:");
           String contacto=teclado.nextLine();
           
           Proprietario novo = new Proprietario(nome,contacto);
           proprietarios.add(novo);
           System.out.println("Proprietario adicionado com sucesso!");
          System.out.println(novo);
          
       } 
     
       //registrar visita
    public void registrarVisita(Scanner teclado){
        System.out.println("Pesquise o animal:");   
        String animal=teclado.nextLine();
        //primeiro buscar o animal pra saber se existe ou nao 
         Animal animalEncontrado = null; //para guardar o nome pra poder ser posteiriromente usado como no registrar vista desse animal,mostarar dados...
         for(int i=0;i<animais.size();i++){
             Animal a= animais.get(i);
             if(a.getnome().equalsIgnoreCase(animal.trim())){
                 animalEncontrado=a;
                 System.out.println("Animal encontrado com sucesso: " + "[" + a.getnome() + "]");
                 break;
             }
          
         }
        
        if (animalEncontrado == null) {
        System.out.println("Animal nao encontrado. Registre-o primeiro.");
        return;
    }
      
      LocalDate data = null;
String tipo = "";
double custo = 0.0;
String veterinario = "";
String observacoes = "";


        while(true){ 
        System.out.println("Digite a data da visita no formato AAA-MM-DD entre 2024-01-01 e 2025-12-30 ");
        String dataVisita=teclado.nextLine();
        
 
        try {
     data = LocalDate.parse(dataVisita.trim());//transforma a data digitada no tipo LocalDate

    if (!Validacao.validardatavisita(data)) { //trata a data valida mas q nao esta no intervalo
        System.out.println("Data invalida: a visita deve estar entre 01-01-2024 e 30-12-2025.Tente novamente");
       
    }else{
        break;
    }
        
    
  
} catch (DateTimeParseException e) {
    System.out.println("Formato invalido. Use o formato AAAA-MM-DD.tente novamente");
}
      }
   System.out.println("Data da visita registrada com sucesso: " + "["+ data + "]");     
       //tipo visita
   while(true){
       System.out.println("Digite o tipo de visita entre higiene,consulta,vacina!"); 
        tipo=teclado.nextLine();
 
       if(Validacao.validarTipoVisita(tipo)){
         System.out.println("Tipo de visita validado: " + "[" + tipo + "]"); 
           break;
       }else{
           System.out.println("tipo invalido! Digite novamente entre higiene,consulta,vacina");
          
       }
      
   }     
    
   while(true){
       try{
        System.out.println("Digite o custo da visita:");
         custo=teclado.nextDouble();
        teclado.nextLine();//limpar o buffer
        
            Validacao.validarcusto(custo);
            System.out.println("Custo da visita registrado: " + custo + "kzs"); 
            break;
        }catch (IllegalArgumentException e){
            System.out.println("custo invalido! Digite um numero valido para o custo.");
            
        }catch(InputMismatchException e){
           System.out.println("Custo inválido: " + e.getMessage());
            return;
        }
        
        
    }     
        System.out.println("Digite o nome do veterinario");   
        String nome=teclado.nextLine();
       
        System.out.println("Digite as observacoes");   
        observacoes=teclado.nextLine();
        
        Visitas novaVisita = new Visitas(data,tipo,custo,nome,observacoes,animalEncontrado);
        animalEncontrado.adicionarVisita(novaVisita);//adiciona visita ao animal

System.out.println("Visita registrada com sucesso para o animal " + animalEncontrado.getnome());

        
        
    }
    



    
   public  void ListarAnimaisProp(ArrayList<Proprietario> proprietarios) {
    if (proprietarios.isEmpty()) {
        System.out.println("Nenhum proprietario registrado.");
        return;
    }

    for (int i = 0; i < proprietarios.size(); i++) {
        Proprietario p = proprietarios.get(i); // pega o proprietário
        System.out.println(p);
        p.ListarAnimaisProp(); // chama o método dentro da classe Proprietario
        
    }
}
    
  public  void ListarTodosAnimais(ArrayList<Animal> animais) {
    if (animais.isEmpty()) {
        System.out.println("Nenhum animal registrado.");
        return;
    }
//registrar animais
    System.out.println("=== Lista de Todos os Animais Registrados ===");
    for(int i=0;i<animais.size();i++) {
        System.out.println(animais.get(i)); 
    }
}  
    
 public void BuscarAnimaisPorProprietario(Scanner teclado) {
    if (proprietarios.isEmpty()) {
        System.out.println("Nenhum proprietario registrado.");
        return;
    }

    System.out.println("Digite o nome do proprietario:");
    String nome= teclado.nextLine().trim();

    Proprietario encontrado = null;
    for (int i=0;i<proprietarios.size();i++) {
        Proprietario p=proprietarios.get(i);
                
        if (p.getnome().equalsIgnoreCase(nome)) {//se prop e igual ao da lista entao guarda na variavel encontrado
            encontrado = p;
            break;
        }
    }

    if (encontrado == null) {
        System.out.println("Proprietário nao encontrado.");
    } else {
        System.out.println("Proprietario encontrado: " + "[" + encontrado.getnome() + "]");
        encontrado.ListarAnimaisProp(); // mostra os animais do proprietário
    }
}
   
    public void ContarVisitasPorTipo(Scanner teclado) {
    if (animais.isEmpty()) {
        System.out.println("Nenhum animal registrado.");
        return;
    }

    System.out.println("Digite o nome do animal:");
    String nomeAnimal = teclado.nextLine().trim();

    Animal encontrado = null;
    for (int i = 0; i < animais.size(); i++) {
        Animal a = animais.get(i);
        if (a.getnome().equalsIgnoreCase(nomeAnimal)) { // se o nome digitado for igual ao da lista este nome e guardado o encontrado pra se poder usar posteriormente
            encontrado = a;
            break;
        }
    }

    if (encontrado == null) {
        System.out.println("Animal nao encontrado.");
        return;
    }

    ArrayList<Visitas> visitas = encontrado.getvisita();//o animal encontrado esta a associado  a classe animal entao conisgmos obter asua lista de visitao == getvistas da classe
    if (visitas.isEmpty()) {
        System.out.println("O animal " + encontrado.getnome() + " ainda nao tem visitas.");
        return;
    }

    int higiene = 0, consulta = 0, vacina = 0;

    for (int i = 0; i < visitas.size(); i++) {
       String tipo = visitas.get(i).getTipoVisita().toLowerCase();//obtem o tipo de visita no arraylist visitas
        //String tipo e o tipo visita q esta dentro da lista de visita q ja foi inserida ao registrar visita
       switch (tipo) {
            case "higiene":
                higiene++;
                break;
            case "consulta":
                consulta++;
                break;
            case "vacina":
                vacina++;
                break;
        }
    }

    System.out.println("=== Estatisticas de visitas do animal: " + encontrado.getnome() + " ===");
    System.out.println("Higiene: " + higiene);
    System.out.println("Consulta: " + consulta);
    System.out.println("Vacina: " + vacina);
    System.out.println("Total de visitas: " + visitas.size());
}
//listar o historico de visittas de um animal
    public void listarHistoricoVisitas(Scanner teclado) {
    if (animais.isEmpty()) {
        System.out.println("Nenhum animal registrado.");
        return;
    }

    System.out.println("Pesquise o nome do animal:");
    String nomeAnimal = teclado.nextLine().trim();
//animalEncontrado do tipo Animal pois dps de encontrar queremos acessar tds os atributos de classseAnimal
    Animal animalEncontrado = null; //null pq ainda nao aponto pra nenhum animal,uma variavell pra guardar no caso de se enoctrar o animal pra podermos usar em ouyro campo
    for (int i = 0; i < animais.size(); i++) {
        Animal a = animais.get(i);//acessa o animal na lista animal
        if (a.getnome().equalsIgnoreCase(nomeAnimal)) {//dps de acessar o animal da listanaimalcompara o nome do animal encontradona na lista com o digitado
            animalEncontrado = a;//se for igual ele guarda em animalEncontrado
            break;
        }
    }

    if (animalEncontrado == null) {
        System.out.println("Animal nao encontrado.");
    } else {
        System.out.println("Historico de visitas do animal " + animalEncontrado.getnome() + ":");
        animalEncontrado.exibirvisitas(); // ja temos esse metodo na classe ANIMAL
    }
}

    
    
    
    
        
}      
        
 
        
        
       
                
    
  
      
       
        
      



    

