
package pungo.andongo;
import java.time.LocalDate;
import java.time.Period;
public class Validacao {
  public static boolean validardatavisita(LocalDate dataVisita){
      LocalDate inicio = LocalDate.of(2024, 1, 1);
      LocalDate fim = LocalDate.of(2025, 12, 30);
        return dataVisita != null && 
           (!dataVisita.isBefore(inicio)) && 
           (!dataVisita.isAfter(fim));//usei o metodo da classe localdate pr caso ante e depois do intervalo dadata
  } 
    
   public static boolean validarTipoVisita(String Tipo){
       if(Tipo ==null) return false;
       Tipo=Tipo.trim().toLowerCase();
       return Tipo.equals("higiene")||Tipo.equals("consulta")||Tipo.equals("vacina");
          
       }
    
 public static void validarcusto(double custo){
     if( custo <= 0){
         throw new IllegalArgumentException("custo nao pode ser negativo");
 }
}


public static void validarDataNascimento(LocalDate data) {
   if(data ==null ){
          throw new IllegalArgumentException("Data de nascimento nao pode ser null.");
      }
       int ano = data.getYear();
    if (ano < 2020 || ano > 2025) {
        throw new IllegalArgumentException("O ano da data deve estar entre 2020 e 2025.");
    }

     int idade = Period.between(data, LocalDate.now()).getYears(); 
      
      if(idade>5){
         throw new IllegalArgumentException ("A idade do Animal nao pode ser maior que 5!");
      }
}  
  




public static void validarDataNaoFutura(LocalDate data) {
    if (data.isAfter(LocalDate.now())) {
        throw new IllegalArgumentException("A data de nascimento nao pode ser maior que 2025.");
    }
}
      
    
      
      
      
      
      
      
      
      
   
   }
  

    
 
    
    
    
    
    
    

