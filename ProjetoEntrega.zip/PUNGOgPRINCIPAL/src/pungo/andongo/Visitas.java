
package pungo.andongo;
import java.time.LocalDate;

public class Visitas {
   private LocalDate DataVisita;
   private String TipoVisita;
    private double custo;
    private String Veterinario;
    private String observacoes;
    private Animal animal;
    
//metodo construtor
public Visitas(LocalDate DataVisita,String TipoVisita,double custo,String Veterinario,String observacoes,Animal animal){
//VALIDACAO DA DATA Q TEM DE ESTAR ANtes O ANO ATUAL 
   
    this.DataVisita=DataVisita;
    
 
    if(Validacao.validarTipoVisita(TipoVisita)){
     this.TipoVisita=TipoVisita.toUpperCase();
    
    }


this.Veterinario=Veterinario.toUpperCase();
try{
    Validacao.validarcusto(custo);
    this.custo=custo;
}catch(IllegalArgumentException e){
      System.out.println("Erro: " + e.getMessage());
      this.custo=custo;
}

this.observacoes=observacoes.toUpperCase();
this.animal=animal;
}
 //metodo contrutor q inicializa
public Visitas(){
this.DataVisita=LocalDate.of(2025,1,1);
this.TipoVisita="indefinido";
this.Veterinario="indefinido";
this.custo=-1;
this.observacoes="indefinido";
}




public Animal getanimal(){
    return this.animal;
}

public LocalDate getdataVisita(){
    return this.DataVisita;
}
  
  public String getTipoVisita(){
      return this.TipoVisita;
  }
  public String getVeterinario(){
      return this.Veterinario;
  }
  public double getcusto(){
      return this.custo;
  }
  public String getobservacoes(){
      return this.observacoes;
  }
  public void setTipoVisita(String TipoVisita){
      this.TipoVisita=TipoVisita;
  }
  public void setDataVisita(LocalDate DataVisita){
      this.DataVisita=DataVisita;
  }
  public void setVeterinario(String Veterinario){
      this.Veterinario=Veterinario;
  }
  public void setcusto(double custo){
      this.custo=custo;
  }
  public void setobservacoes(String observacoes){
       this.observacoes=observacoes;
  }


@Override
  public String toString(){ 
      return "Visita[DataVisita= " + DataVisita + ", TipoVisita= " + TipoVisita + ", custo= " + custo + ", observacoes= " + observacoes + ", Veterinario= " + Veterinario + ", Animal= " + animal+ "]" ;
  }    
      





}