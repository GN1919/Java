
package pungo.andongo;

public class Superclasse {
   protected String nome;
   protected String id;
    
    
}
